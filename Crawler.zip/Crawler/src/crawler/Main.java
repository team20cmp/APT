/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package crawler;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.Locale;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.jsoup.Jsoup;
import org.jsoup.examples.HtmlToPlainText;
import org.jsoup.nodes.Document;
import static org.jsoup.nodes.Document.OutputSettings.Syntax.html;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;



/**
 *
 * @author dell
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws SQLException, FileNotFoundException, IOException {
        
             Inverted_Index I= new Inverted_Index();
             File input = new File("html");  // pages in folder "html" // 
             File[] st = input.listFiles();
             for (int i = 0; i < st.length; i++) {
               if(st[i].isFile()){
                
                  FileOutputStream f ;
                  Parser.Parsing(st[i]);
                  String f_name=st[i].getName();
           f_name = f_name.substring(0, f_name.lastIndexOf("."));
                  String [] Words=Parser.get_arr();   //array of strings mona
                  
                  int [] tags= Parser.get_tag();
                  //if(tags==null)
                    //  System.out.print("sd");
                   //   System.out.println(Words.length);
                /*  for(int j=0;j<Words.length;j++)
                  {
                     System.out.println(Words[j]);
                  }
                 */
                 Words=Steming_Part.return_stem(Words);
                    
                 I.Add_Positions(Words,f_name,tags);
                    //I.Print_Positions();
                 // PrintWriter out=Parser.get_file();// sarah
                  
                          
               }
             }
          
            
            
            
    
    
    }}
