package crawler;

class NewString {
  public String str;
  NewString() {   str = "";  }
}
public class Stemmer {
    public String Clean( String str ) {
        int last = str.length();
        Character ch = new Character( str.charAt(0) );
        String temp = "";
       
        for ( int i=0; i < last; i++ ) {            
            if ( ch.isLetterOrDigit( str.charAt(i) ) )
                temp += str.charAt(i);
        }
        return temp;
    }
 
    public  boolean check_suffix( String word, String suffix, NewString stem ) {
        String tmp = "";
        if ( word.length() <= suffix.length() )
            return false;
        if (suffix.length() > 1) 
        if ( word.charAt( word.length()-2 ) != suffix.charAt( suffix.length()-2 ) )
            return false;
        
        stem.str = ""; 
        for ( int i=0; i<word.length()-suffix.length(); i++ )
            stem.str += word.charAt( i );
        tmp = stem.str;

        for ( int i=0; i<suffix.length(); i++ )
            tmp += suffix.charAt( i );

        if ( tmp.compareTo( word ) == 0 )
            return true;
        else
            return false;
    }   
    
    public boolean Check_vowel( char ch, char prev ) {
        switch ( ch ) {
            case 'a': case 'e': case 'i': case 'o': case 'u':
                return true;
            case 'y': {
                switch ( prev ) {
                    case 'a': case 'e': case 'i': case 'o': case 'u': 
                        return false;
            default: 
              return true;
                }
            }
        default : 
            return false;
        }
    }

    public int measure( String stem ) {    
    int i=0, count = 0;
    int length = stem.length();

    while ( i < length ) {
        for ( ; i < length ; i++ ) {
            if ( i > 0 ) {
                if ( Check_vowel(stem.charAt(i),stem.charAt(i-1)) )
                    break;
           }
           else {               
                if ( Check_vowel(stem.charAt(i),'a') )
                    break; 
           }
       }

        for ( i++ ; i < length ; i++ ) {
            if ( i > 0 ) {
                if ( !Check_vowel(stem.charAt(i),stem.charAt(i-1)) )
                    break;
            }
            else {  
                if ( !Check_vowel(stem.charAt(i),'?') )
                    break;
           }
        } 
        if ( i < length ) {
           count++;
            i++;
        }
    } //while    
       return(count);
    }

    public boolean containsVowel( String word ) {
        for (int i=0 ; i < word.length(); i++ )            
            if ( i > 0 ) {
                if ( Check_vowel(word.charAt(i),word.charAt(i-1)) )
                   return true;
            }
            else {  
                if ( Check_vowel(word.charAt(0),'a') )
                   return true;
            }        
     return false;
    }

    public boolean Check( String str ) {
        int length=str.length();    
        if ( length < 3 )
            return false;
    
        if ( (!Check_vowel(str.charAt(length-1),str.charAt(length-2)) )
        && (str.charAt(length-1) != 'w') && (str.charAt(length-1) != 'x') && (str.charAt(length-1) != 'y')
        && (Check_vowel(str.charAt(length-2),str.charAt(length-3))) ) {
            if (length == 3) {
               if (!Check_vowel(str.charAt(0),'?')) 
                return true;
            else
                return false;
        }
        else {
           if (!Check_vowel(str.charAt(length-3),str.charAt(length-4)) ) 
                return true; 
           else
                return false;
        } 
        }      
        return false;
    }

    public String Stemming( String str ) {
       
    NewString stem = new NewString();
    String tmp = "";
    
    if ((!check_suffix( str, "s", stem ) && str.charAt( str.length()-1 ) == 'e' ))
        return str;
    
    if ( str.charAt( str.length()-1 ) == 's' ){
        if ((check_suffix( str, "ous", stem )) || (check_suffix( str, "is", stem )) ||(check_suffix( str, "us", stem ))){
            return str;
    }
        if ( (check_suffix( str, "sses", stem )) ){
            for (int i=0; i<str.length()-2; i++)
                tmp += str.charAt(i);          
            str = tmp;          
        }
        if ( (check_suffix( str, "ies", stem)) )
        {
            for (int i=0; i<str.length()-3; i++)
                tmp += str.charAt(i);          
            str = tmp+"y";          
       }
        else {
            if ( ( str.length() == 1 ) && ( str.charAt(str.length()-1) == 's' ) ) {
                str = "";
                return str;
            }
            else if ( ( str.length() == 2 ) && ( str.charAt(str.length()-1) == 's' ) )
                return str;
            else if ( str.charAt( str.length()-2 ) != 's' ) {      
                for (int i=0; i<str.length()-1; i++)
                    tmp += str.charAt(i);
                str = tmp;
           }
        }  
     }
         if ( check_suffix( str,"eed",stem ) ) {
           if ( measure( stem.str ) > 0 ) {
              for (int i=0; i<str.length()-1; i++)
                  tmp += str.charAt( i );
              str = tmp;
           }
     }
     else {  
        if (  (check_suffix( str,"ed",stem )) || (check_suffix( str,"ing",stem )) ) { 
           if (containsVowel( stem.str ))  {
              for ( int i = 0; i < stem.str.length(); i++)
                  tmp += str.charAt( i );
              str = tmp;
              if ( str.length() == 1 )
                 return str;

              else {   
                 int length = str.length(); 
                 if ( (str.charAt(length-1) == str.charAt(length-2)) 
                    && (str.charAt(length-1) != 'l') && (str.charAt(length-1) != 's') && (str.charAt(length-1) != 'z') ) {
                     
                    tmp = "";
                    for (int i=0; i<str.length()-1; i++)
                        tmp += str.charAt(i);
                    str = tmp;
                 }
              }
           }
        }
     }
         

         

   if ( str.charAt(str.length()-1) == 'e' ) { 
        if ( measure(str) > 1 ) {// measure(str)==measure(stem) if ends in vowel 
            tmp = "";
            for ( int i=0; i<str.length()-1; i++ ) 
                tmp += str.charAt( i );
            str = tmp;
        }
        else
        if ( measure(str) == 1 ) {
            String st="";
            for ( int i=0; i<str.length()-1; i++ ) 
                st += str.charAt( i );
                if ( !Check(st) )
                    str = st;
        }
    }
    return str; 
    }

    public String Prepare_Stemming( String str ) {
        str = str.toLowerCase();
        str = Clean(str);
        if (str != "" ) 
            str = Stemming( str );
        return str;
    }
}
