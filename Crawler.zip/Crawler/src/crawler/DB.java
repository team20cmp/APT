/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package crawler;

/**
 *
 * @author Safaa
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
 
public class DB {
 
	public Connection conn = null;
 
	public DB() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			String url = "jdbc:mysql://localhost:3306/crawler";
			conn = DriverManager.getConnection(url, "root", "");
			System.out.println("conn built");
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
 
	public ResultSet runSql(String sql) throws SQLException {
		Statement sta = conn.createStatement();
		return sta.executeQuery(sql);
	}
 
	public boolean runSql2(String sql) throws SQLException {
		Statement sta = conn.createStatement();
		return sta.execute(sql);
	}
     
 
/**
     *
     * @param index
     * @return
     * @throws SQLException
     */
    public boolean check_index(String index) throws SQLException
       {
            String query =" SELECT index_ FROM indexes WHERE index_= '" + index + "' ";
          return !  runSql(query).next();
            
       }
       
       public boolean check_doc(String  doc) throws SQLException
       {
            String query = " SELECT * FROM postions WHERE Doc_Id= '" + doc + "' ";
          return !  runSql(query).next();
            
       }
       public boolean check_doc2(String  doc) throws SQLException
       {
            String query = " SELECT * FROM documents WHERE Doc_Id= '" + doc + "'";
          return !  runSql(query).next();
            
       }
       public boolean insert_doc(String  doc,String index,int freq) throws SQLException
       {
            String query =  "INSERT INTO documents (Doc_Id,index_,freq) " + "VALUES ('"+doc+"','"+index+"','"+freq+"')";
           boolean  x=runSql2(query);
            if(x)
                System.out.println("doc inserted sucesfully");
          return  x;
            
       }
       
       public boolean insert_pos(String  doc,String index,int tag,int pos) throws SQLException
       {
            String query =  "INSERT INTO postions (Doc_Id,index_,tag,pos) " + "VALUES ('"+doc+"','"+index+"','"+tag+"','"+pos+"')";
           boolean  x=runSql2(query);
            if(x)
                System.out.println("postions inserted sucesfully");
          return  x;
            
       }
       
        public boolean insert_index(String index) throws SQLException
       {
            String query =  "INSERT INTO indexes " + "VALUES ('"+index+"')";
             boolean  x=runSql2(query);
            if(x)
                System.out.println("index inserted sucesfully");
          return  x;
            
       }
        
        public boolean update_doc(String  doc,String index,int freq) throws SQLException
       {
            String query =  "UPDATE documents " + "SET freq = '"+freq+"' WHERE Doc_Id = '"+doc+"' AND index_ = '"+index+"'";
             boolean  x=runSql2(query);
            if(x)
                System.out.println("doc Updated sucesfully");
          return  x;
            
       }
        public boolean delete_doc(String  doc,String index) throws SQLException
       {
            String query =  "DELETE FROM documents " +" WHERE Doc_Id = '"+doc+"' AND index_ = '"+index+"'";
             boolean  x=runSql2(query);
            if(x)
                System.out.println("doc Updated sucesfully");
          return  x;
            
       }
        public boolean delete_doc2(String  doc) throws SQLException
       {
            String query =  "DELETE FROM documents " +" WHERE Doc_Id = '"+doc+"' ";
             boolean  x=runSql2(query);
            if(x)
                System.out.println("doc Updated sucesfully");
          return  x;
            
       }
        public boolean delete_pos(String  doc,String index,int tag) throws SQLException
       {
            String query =  "DELETE FROM postions " + "WHERE Doc_Id = '"+doc+"' AND index_='"+index+"' AND tag='"+tag+"' ";
             boolean  x=runSql2(query);
            if(x)
                System.out.println("pos deleted sucesfully");
          return  x;
            
       }
        public boolean delete_pos2(String  doc) throws SQLException
       {
            String query =  "DELETE FROM postions " + "WHERE Doc_Id = '"+doc+"' ";
             boolean  x=runSql2(query);
            if(x)
                System.out.println("pos deleted sucesfully");
          return  x;
            
       }
	@Override
	protected void finalize() throws Throwable {
		if (conn != null || !conn.isClosed()) {
			conn.close();
		}
	}
}