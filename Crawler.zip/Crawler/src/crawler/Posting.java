/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package crawler;

import java.util.HashMap;
import java.util.Vector;

/**
 *
 * @author MONA
 */
class Posting {
    String DocId;
    int freq;
   // int [] tag;
  HashMap<Integer, Vector <Integer> > postions;
   public Posting()
   {
     //  tag= new int [2];
       postions= new HashMap <>();
   }
}
