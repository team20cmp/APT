/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package crawler;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

/**
 *
 * @author dell
 */
public class Parser {
   public static String[] stopwords ={"a", "about", "above", "above", "across", "after", "afterwards", "again", "against", "all", "almost", 
                "alone", "along", "already", "also","although","always","am","among", "amongst", "amoungst", "amount",  "an", "and", 
                "another", "any","anyhow","anyone","anything","anyway", "anywhere", "are", "around", "as",  "at", "back","be","became", 
                "because","become","becomes", "becoming", "been", "before", "beforehand", "behind", "being", "below", "beside", "besides", 
                "between", "beyond", "bill", "both", "bottom","but", "by", "call", "can", "cannot", "cant", "co", "con", "could", "couldnt",
                "cry", "de", "describe", "detail", "do", "done", "down", "due", "during", "each", "eg", "eight", "either", "eleven","else",
                "elsewhere", "empty", "enough", "etc", "even", "ever", "every", "everyone", "everything", "everywhere", "except", "few", 
                "fifteen", "fify", "fill", "find", "fire", "first", "five", "for", "former", "formerly", "forty", "found", "four", "from", 
                "front", "full", "further", "get", "give", "go", "had", "has", "hasnt",
                "have", "he", "hence", "her", "here", "hereafter", "hereby", "herein", "hereupon", "hers", "herself", 
                "him", "himself", "his", "how", "however", "hundred", "ie", "if", "in", "inc", "indeed", "interest", "into", 
                "is", "it", "its", "itself", "keep", "last", "latter", "latterly", "least", "less", "ltd", "made", "many", 
                "may", "me", "meanwhile", "might", "mill", "mine", "more", "moreover", "most", "mostly", "move", "much", "must", 
                "my", "myself", "name", "namely", "neither", "never", "nevertheless", "next", "nine", "no", "nobody", "none", 
                "noone", "nor", "not", "nothing", "now", "nowhere", "of", "off", "often", "on", "once", "one", "only", "onto", 
                "or", "other", "others", "otherwise", "our", "ours", "ourselves", "out", "over", "own","part", "per", "perhaps",
                "please", "put", "rather", "re", "same", "see", "seem", "seemed", "seeming", "seems", "serious", "several", "she",
                "should", "show", "side", "since", "sincere", "six", "sixty", "so", "some", "somehow", "someone", "something", 
                "sometime", "sometimes", "somewhere", "still", "such", "system", "take", "ten", "than", "that", "the", "their", 
                "them", "themselves", "then", "thence", "there", "thereafter", "thereby", "therefore", "therein", "thereupon", 
                "these", "they", "thickv", "thin", "third", "this", "those", "though", "three", "through", "throughout", "thru", 
                "thus", "to", "together", "too", "top", "toward", "towards", "twelve", "twenty", "two", "un", "under", "until", 
                "up", "upon", "us", "very", "via", "was", "we", "well", "were", "what", "whatever", "when", "whence", "whenever",
                "where", "whereafter", "whereas", "whereby", "wherein", "whereupon", "wherever", "whether", "which", "while", 
                "whither", "who", "whoever", "whole", "whom", "whose", "why", "will", "with", "within", "without", "would", "yet",
                "you", "your", "yours", "yourself", "yourselves","1","2","3","4","5","6","7","8","9","10","1.","2.","3.","4.","5.","6.","11",
                "7.","8.","9.","12","13","14","A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z",
                "terms","CONDITIONS","conditions","values","interested.","care","sure",".","!","@","#","$","%","^","&","*","(",")","{","}","[","]",":",";",",","<",".",">","/","?","_","-","+","=",
                "a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z",
                "contact","grounds","buyers","tried","said,","plan","value","principle.","forces","sent:","is,","was","like",
                "discussion","tmus","diffrent.","layout","area.","thanks","thankyou","hello","bye","rise","fell","fall","psqft.","http://","km","miles"};
   
   public static String [] f_arr;
   private static int [] Tags;
   public static PrintWriter out;
   
      private Parser()
       {
                  
       }
      
    public static boolean isStopWord(String str) {
		
       int flag=1;
       for (String stopword : stopwords) {
           if (str.equals(stopword)||str.length()<=2) {
               flag=0;
               break;
           }
       }
       if(flag==0)
       return true;
       else
           return false;
}
		
	
     public static void Parsing (File f)throws SQLException, IOException 
     {
         
         try {
             
            Document doc = Jsoup.parse(f, "UTF-8");
            
            /*String f_name=f.getName();
            f_name = f_name.substring(0, f_name.lastIndexOf("."))+".txt";
            FileOutputStream fos = new FileOutputStream(f_name);
            PrintWriter out = new PrintWriter(new OutputStreamWriter(fos, "UTF-8"));  // طامحة */
            String[] temp_arr=null; // array of strings   //mona part
            int[] tags=null;     //  
            Elements Body = doc.body().select("*");
            Elements Head = doc.head().select("*");
             //Elements Head2=doc.getElementsByTagName('head')[0];//.innerHTML;
             StringBuilder res = new StringBuilder();
             int count1=0;
             int count2=0;
             int count3=0;
             int c=0;
            for (Element element :Head) {
                if(!(element.ownText().isEmpty()))
                {
                   for(int i=0;i<element.ownText().split("\\P{Alpha}+",-1).length;i++)
                        {
                             String str=element.ownText().split("\\P{Alpha}+",-1)[i];
                             str=str.toLowerCase().replaceAll("[^A-Za-z0-9]", " ");
                            if(!str.equals(" ")&&!(isStopWord(str)))
                            {
                                res.append(str); 
                                 res.append(" ");
                                if(element.tagName().toString().equals("title"))
                                {
                                    
                                count1++;
                                }
                                 else
                                {
                                count2++;
                                
                                }
                            }
                        }
                 }
       
            } 
            
            for (Element element :Body) {
                if(!(element.ownText().isEmpty()))
                {
                   for(int i=0;i<element.ownText().split("\\P{Alpha}+",-1).length;i++)
                        {
                             String str=element.ownText().split("\\P{Alpha}+",-1)[i];
                             str=str.toLowerCase().replaceAll("[^A-Za-z0-9]", " ");
                            if(!str.equals(" ")&&!(isStopWord(str)))
                            {
                                res.append(str); 
                                 res.append(" ");
                                 count3++;
                                 
                            }
                        }
                 }
       
        } 
            temp_arr=new String [res.toString().split("\\P{Alpha}+",-1).length-1];
            Tags=new int [res.toString().split("\\P{Alpha}+",-1).length-1];
           // temp_arr=res.toString().split("\\P{Alpha}+",-1);
           //System.out.println(res.toString().split("\\P{Alpha}+",-1).length-1);
            for(int i=0;i<res.toString().split("\\P{Alpha}+",-1).length-1;i++)
            {
                
                temp_arr[i]=res.toString().split("\\P{Alpha}+",-1)[i];
                //System.out.println(temp_arr[i]);
                if(i<count1)
                Tags[i]=2;
              
                else if(i<count1+count2)
                   Tags[i]=1;
                 
                else
                     Tags[i]=0;
                    
            }
            for(int i=0;i<temp_arr.length;i++)
            {
              // System.out.println(temp_arr[i]);
            }
              set_arr(temp_arr);
             set_Tag(Tags);
              
         }catch (IOException ex) {
            Logger.getLogger(JavaApplication5.class.getName()).log(Level.SEVERE, null, ex);
        }
           
     }
     
     public static void set_arr (String [] f) 
     {
        
         Parser.f_arr=f;
     }
     public static String []  get_arr () 
     {
         //System.out.println(this.f_arr[5]);
         return Parser.f_arr;
     }
      public static void set_Tag (int [] f) 
     {
         Parser.Tags=f;
     }
     public static int []  get_tag () 
     {
         return Parser.Tags;
     }
     
     
     
     
     
     
}
