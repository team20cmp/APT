/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package crawler;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.Vector;

/**
 *
 * @author MONA
 */
public class Inverted_Index {
    /**
     * @param args the command line arguments
     */
   // String Words[];
    
    HashMap<String, Vector <Posting> > All_Indexs;
    int [] doc_Id;
    DB data_base; 
    public Inverted_Index()
    {
        
        All_Indexs=new HashMap <>();
        data_base= new DB (); 
      
    }
   public void Add_Positions(String Words[],String Doc_Id,int [] tags) throws SQLException
    {  Vector <Posting> attr;
        Vector <Integer>  poss;
        HashMap<String, Vector <Posting> > Indexs;
        Indexs = new HashMap <>();
        int count=0;
        int count1=0;
        int count2=0;
        int count3=0;
        for (String key : Words) {
           
            if(Indexs.get(key)==null)
            {   
                //System.out.println("1");
               // System.out.println(tags[count]);
                attr = new Vector(0);
                poss=new Vector(0);
                Posting object= new Posting();
               
               object.DocId=Doc_Id;
               object.freq=1;
               if(tags[count]==0)
               { 
                  count1++;
                   poss.add(count1);
               }
               else if(tags[count]==1)
               { 
                 count2++;
                  poss.add(count2);
               }
               else
               {
                   count3++;
                  poss.add(count3);
               }
                object.postions.put(tags[count],poss);
               attr.add(object);
              
               Indexs.put(key,attr);
            
                
                
            }
                    
            else
            { 
            // System.out.println(tags[count]);
           Posting object= new Posting();
           //object.DocId=Doc_Id;
           object=Indexs.get(key).elementAt(0);
           object.freq = Indexs.get(key).elementAt(0).freq+1;
           attr = Indexs.get(key);
           poss=attr.elementAt(0).postions.get(tags[count]);
           if(poss==null)
           {
               poss=new Vector(0);
           }
               
          
           { if(tags[count]==0)
              {count1++;
               poss.add(count1);
              }
           else if(tags[count]==1)
               { 
                 count2++;
                  poss.add(count2);
               }
               else
               {
                   count3++;
                  poss.add(count3);
               }
           }
         //  System.out.println(tags[count]);
           object.postions.put(tags[count],poss);
           attr.set(0, object);
           Indexs.put(key,attr);
          
            }
             
            count++;
            //System.out.println();
           
        }
        
        Insert_position(Indexs);
    
            
    }
   
    public void Print_Positions()
    {
        for(HashMap.Entry<String, Vector <Posting> > entry: All_Indexs.entrySet()) 
        {
             Vector <Posting>  pos=entry.getValue();
            // System.out.println(pos.size());
            System.out.println(entry.getKey());
             for(int i=0;i<1;i++) 
        {                
             //System.out.println(i);
             System.out.println(  pos.elementAt(i).DocId+ " : "+pos.elementAt(i).freq );
             HashMap<Integer, Vector <Integer> > postions;
             postions=pos.elementAt(i).postions;
             for(HashMap.Entry<Integer, Vector <Integer> > entry1: postions.entrySet()) 
              {
                  System.out.println("tag_kind :" +entry1.getKey());
                  for(int k=0;k<entry1.getValue().size();k++)
                  System.out.print(entry1.getValue().elementAt(k)+ "  ");
                   System.out.println();
              }
        }
        
        }
    }
    
    public void Merg_indexes(HashMap<String, Vector <Posting>> Indexs)
    {
        
        Set<Map.Entry<String, Vector <Posting>>> entries = Indexs.entrySet();
        if(All_Indexs.isEmpty())
             {   
                 All_Indexs=Indexs;
                 
              
             }
           else
            {  
    for ( HashMap.Entry<String, Vector <Posting> > entry : entries ) 
    {      
           
              Vector <Posting> secondMapValue = All_Indexs.get( entry.getKey() );
       if ( secondMapValue == null ) 
          {
            //System.out.println("1");
           All_Indexs.put( entry.getKey(), entry.getValue() );
          }
       else 
          {  
              Posting object= new Posting();
              object.DocId=entry.getValue().elementAt(0).DocId;
              object.freq = entry.getValue().elementAt(0).freq;
              Vector<Posting > pos = All_Indexs.get(entry.getKey());
              pos.addElement(object);
           
              
          }
          }
  
    }
      // All_Indexs.putAll(Indexs);
    }
    
    public void Insert_position(HashMap<String, Vector <Posting>> Indexs) throws SQLException
    {
        
        Set<Map.Entry<String, Vector <Posting>>> entries = Indexs.entrySet();
          HashMap<Integer, Vector <Integer> > postions;
                      
                 All_Indexs=Indexs;
                 
              //   DB data_base= new DB (); 
                 
                
                  boolean doc_notexist;
                  int count=0;
                  
                 for ( HashMap.Entry<String, Vector <Posting> > entry : entries ) 
                  { 
                      //  System.out.println(entry.getKey());
                      
                      
                       
                       
                       
                        if(count==0)
                        {   
                            doc_notexist=data_base.check_doc2(entry.getValue().elementAt(0).DocId);
                            
                            if(!doc_notexist)
                            {  //System.out.println("doc inserted sucesfully");
                              data_base.delete_doc2(entry.getValue().elementAt(0).DocId);
                             // data_base.delete_pos2(entry.getValue().elementAt(0).DocId);
                            }
                            if(!data_base.check_doc(entry.getValue().elementAt(0).DocId))
                             data_base.delete_pos2(entry.getValue().elementAt(0).DocId);
                        }
                      /*  if(data_base.check_index(entry.getKey()))
                          {  //System.out.println("inserted sucesfully");
                             data_base.insert_index(entry.getKey());
                          
                              
                          }*/
                      
                      
                     data_base.insert_doc(entry.getValue().elementAt(0).DocId,entry.getKey(),entry.getValue().elementAt(0).freq);
                     
                  postions=entry.getValue().elementAt(0).postions;
                for(HashMap.Entry<Integer, Vector <Integer> > entry1: postions.entrySet()) 
              {
                 // System.out.println("tag_kind :" +entry1.getKey());
                  for(int k=0;k<entry1.getValue().size();k++)
                  { 
                      data_base.insert_pos(entry.getValue().elementAt(0).DocId,entry.getKey(),entry1.getKey(),entry1.getValue().elementAt(k) );
         
                  }
              }
                      
           count++;
          
                      }
   }
}

