/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package crawler;

/**
 *
 * @author Safaa
 */
import org.apache.commons.collections.PredicateUtils;
import com.trigonic.jrobotx.RobotExclusion;
//import io.mola.galimatias.GalimatiasParseException;
//import io.mola.galimatias.StrictErrorHandler;
//import io.mola.galimatias.URLParsingSettings;
//import ch.sentric.UrlUtil;
import com.ibm.icu.text.IDNA;
//import io.mola.galimatias.URLUtils;
//import io.mola.galimatias.canonicalize.DecodeUnreservedCanonicalizer;
//import io.mola.galimatias.canonicalize.URLCanonicalizer;
import org.apache.log4j.Appender;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.io.Serializable;
import java.net.HttpURLConnection;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Scanner;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.apache.log4j.BasicConfigurator;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;


class url_class implements Serializable
{
   String [] URL;
 int NextURLID=0;
int depth=0;
    LinkedList<String> listURL;
    public url_class(String [] URL,int i,int d,LinkedList<String> listURL) {
        this.listURL = listURL;
       
        this.URL=URL;
        NextURLID=i;
        depth=d;
    }
}

public class Crawler implements Runnable{

 static final Object o= new Object();
  private static int NextURLID=0;
  public  static int nThread = 1;
   public  static int d=0;
  private static String [] URL;
 public  static int f=0 ;
 private static LinkedList<String> listURL;
     Crawler() throws IOException
     {
         this.listURL = new LinkedList<>();
      URL=new String [30];//max numof threads
       
     }
  @Override
      public void run()
   {
      try
      {  
          String url=GEt_URL();
          try{processPage(url,0);}
         catch ( IOException | SQLException e) {System.out.println("error "+e.getMessage()+" while processing page");}
          
      }
      catch (Exception e) {}
      if(Thread.interrupted())try {
          serialize();
      } catch (IOException ex) {
          Logger.getLogger(Crawler.class.getName()).log(Level.SEVERE, null, ex);
      }
   }
       public boolean isHTML(String link)
   {
      URL url;
      HttpURLConnection urlc = null;
      try
      {
         url = new URL(link);
         urlc = (HttpURLConnection) url.openConnection();
         urlc.setAllowUserInteraction(false);
         urlc.setDoInput(true);
         urlc.setDoOutput(false);
         urlc.setUseCaches(true);
         
         // Only get the head of the document to save space and time
         urlc.setRequestMethod("HEAD");
         urlc.connect();
         
         // Check the content type to make sure the document is HTML
         String mime = urlc.getContentType();
         if (mime.contains("text/html"))
         {
            return true;
         }
      }
      catch (Exception e)
      {
         //e.printStackTrace();
      }
      finally
      {
         if(urlc != null)
            urlc.disconnect();
      }

      return false;
   }
   
////choose seeds and get next url
     public synchronized void serialize() throws FileNotFoundException, IOException
     {
                  url_class s1 =new url_class(URL,NextURLID,d,listURL);  
		  //create file which we will write the stream of bytes in it
		  FileOutputStream fout=new FileOutputStream("state.txt");  
      // write the object
      try ( //create an object outstream to write the stream in the file
              ObjectOutputStream out = new ObjectOutputStream(fout)) {
          // write the object
          out.writeObject(s1);
          System.out.println(s1.NextURLID);
          //flush to make sure it is written
          out.flush();
            System.out.println("Saving the current state....");
      }
     
     
     }
     //////////////////
     public synchronized void  deserialize() throws Exception
     {
     
     
      //we cast the bytes back to its original typpe
         try (ObjectInputStream in = new ObjectInputStream(new FileInputStream("state.txt"))) {
          //we cast the bytes back to its original typpe
          url_class u=(url_class)in.readObject();
          URL=u.URL;
          NextURLID=u.NextURLID+1;//d=u.depth;
          listURL=u.listURL;
            System.out.println("Get last state....");
           
      }
     
     }
     //////////////
    public  String  GEt_URL () throws IOException, FileNotFoundException, ClassNotFoundException, Exception
    { String [] seeds=new String [30];
   // seeds[0]="http://www.dmoz.org/";
    seeds[1]="https://www.wikipedia.org/";
    seeds[2]="https://maktoob.yahoo.com/";
    seeds[3]="https://twitter.com/";
    seeds[4]="http://stackexchange.com/";  
    seeds[5]="http://stackoverflow.com/";
    seeds[6]="http://www.bbc.com/";
    seeds[7]="https://www.nasa.gov/";
    seeds[8]="http://www.samplenews.com";
    seeds[9]="http://www.ics.uci.edu/";
    seeds[10]="https://news.ycombinator.com/";
    seeds[11]="http://digg.com/";
    seeds[12]="http://www.citeulike.org/";
    seeds[13]="http://www.myhq.com/";
    seeds[14]="http://www.slashdot.org/";
    seeds[15]="https://www.searchenginejournal.com/";
    seeds[16]="https://www.cnet.com/";
    seeds[17]="http://www.ox.ac.uk/";
    seeds[18]="http://www.harvard.edu/";
    seeds[19]="http://web.mit.edu/";
    seeds[0]="https://www.ibm.com/";
    
    
     int i =Integer.parseInt(Thread.currentThread().getName());
   BufferedReader br = new BufferedReader(new FileReader("state.txt"));     
if (br.readLine() != null) {
    deserialize();
} 
   
    if(URL[i]==null)
    {
    if(i<20)
    URL[i]= seeds[i];
    else URL[i]= seeds[0];        
    
    }
    System.out.println("Thread "+i+"chosed urL "+URL[i]);
    return URL[i];
    }
    
   
   
    //////////////////
    // Download page at given URL.
    public   String downloadPage(URL pageUrl) {
        try {                   
            String sURL=pageUrl.toString();
            BufferedWriter writer;
            try ( 
                 BufferedReader reader = new BufferedReader(new InputStreamReader( pageUrl.openStream()))) {
                 String  title="html/"+String.valueOf(NextURLID)+".html";
                // Read page into buffer.
                writer = new BufferedWriter(new FileWriter(title));
                String line;
                while ((line = reader.readLine()) != null) {
                 //   System.out.println(line);
                    writer.write(line);
                    writer.newLine();
                }   
                System.out.println("Downloading file of "+sURL+"....");
            }
      writer.close();
            return null;
        } catch (IOException e) {
            System.err.println("can not download file");
        }
         
        return null;
    }
      //////////////
    boolean is_robottxt_exist(URL url)
    { boolean b;
     try {
               String host = url.getHost().toLowerCase();
                URL robotsFileUrl =new URL("http://" + host + "/robots.txt");
                 BufferedReader reader = new BufferedReader(new InputStreamReader( robotsFileUrl.openStream()));
                 b=true;
     }
     catch(Exception e){System.out.println(url.toString()+" do not have robot.txt"); b=false;}
    return b;
    }
 boolean is_visited(String u) throws SQLException
 {
 String sql = "select * from Record where URL = '"+u+"'";
  ResultSet rs;
  rs = db.runSql(sql);
     return rs.next();
 
 
 
 }
    /////////////
    	public  void processPage(String sURL,int depth) throws SQLException, IOException{
                 if (NextURLID==3000)return;///////stopping critria 
                 if (sURL.contains("login")) return;
                  RobotExclusion robotExclusion = new RobotExclusion();
                  
                  ch.sentric.URL url2=new ch.sentric.URL(sURL);
                  String    URL=url2.getNormalizedUrl();
                  URL url=new URL (sURL);
             //     if (depth==12)return;
	
              boolean isrobotallowed;
               
                
                 String s=Thread.currentThread().getName();
                    int i=Integer.parseInt(s);
               
                if(is_robottxt_exist(url))
                {  isrobotallowed=robotExclusion.allows(url, "*");}
                else isrobotallowed=true;
		if(is_visited(URL)){
                    synchronized(o)
                    {
                    while(!Crawler.listURL.isEmpty())
                    {
                   if(!is_visited( Crawler.listURL.getFirst()))
                       processPage(Crawler.listURL.pollFirst(), depth);
                   else
                       Crawler.listURL.pollFirst();
                    }
                    }
		}else if (isrobotallowed){
                    
                    //store the URL to database to avoid parsing again
			String sql =" insert into Record (URL, id)"+ " values ( ?, ?)";

			PreparedStatement stmt = db.conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
                         synchronized (o) 
                        {
			
			stmt.setString(1, URL);
                        stmt.setInt (2, NextURLID);
			stmt.executeUpdate();
                        downloadPage(url);
                        NextURLID=NextURLID+1;
                          serialize();  
                                
                         }
			//get useful information
			Document doc = Jsoup.connect(sURL).timeout(0).get();
                        System.out.println("connect to web..");
                        
			  
                                 
				//System.out.println(URL +s);
			
                       
			//get all links and recursively call the processPage method
			Elements questions = doc.select("a[href]");
                         System.out.println("get the url..");
                         int c=0;
                         for(Element link: questions)
                         {
                        Crawler.listURL.addLast(link.attr("abs:href"));
                         }
			for(Element link: questions)
                        {
                                // Skip empty links &&just page anchors && mailto links &&JavaScript links
                                if(!( (sURL.length() < 1)&& (sURL.charAt(0) == '#')&&(sURL.contains("mailto:"))&&(sURL.toLowerCase().contains("javascript"))&&isHTML(sURL)))
                                {
                                      System.out.println("current depth is"+depth);
                                   Crawler.URL[i]=link.attr("abs:href");
                                   d=depth+1;
                                    
                                    processPage(link.attr("abs:href"),depth+1);
                              synchronized(o)   {  serialize();}
                                }
                                else
                                    System.out.println(sURL+"Not An Html");
                                
                        }
                                     
                                
                }
                else
                        System.err.println(sURL+" disallow Robot ");

           //   serialize();
        }
   
   public static DB db = new DB();
 
	public static void main(String[] args) throws SQLException, IOException {
                BasicConfigurator.configure();
		boolean first=false;
		 Scanner reader = new Scanner(System.in);  // Reading from System.in
          ////////take input for A////////
               System.out.println("Enter  number of Threds : ");
               nThread = reader.nextInt(); // Scans the next token of the input as an int.
                Crawler crawler[]=new Crawler [nThread];
          //   
                 //Create the threads
                //////////////
      Thread threads[] = new Thread[nThread];
      for(int i = 0; i < threads.length; i++)
      {
         crawler[i]=new Crawler();
         threads[i] = new Thread(crawler[i]); 
         threads[i].setName(String.valueOf(i));
      }
      
      // Crawl that sucker
    new java.util.Timer().scheduleAtFixedRate( 
       new java.util.TimerTask() {
            @Override
          public void run() {
               try
      {
          
         System.out.println("Initializing Crawl Sequence...");
         System.out.println("Crawling...");
         System.out.println("-------------------------------------------");
        Scanner scanner = new Scanner(new File("out.txt"));
        if(scanner.hasNextInt()){
           f = scanner.nextInt();
             }
         if(Crawler.f==1){
         
         db.runSql2("TRUNCATE Record;");
         PrintWriter writer = new PrintWriter("state.txt");
         writer.print("");
         writer.close();
         
         
         }
         for(int i = 0; i < threads.length; i++)
         {
             threads[i].start();
             System.out.println("thread"+i+"Started");
         }
                    for (Thread thread : threads) {
                        thread.join();                          
                    }
      }
      catch (InterruptedException e)
      {
         
      }         catch (SQLException ex) {
                    Logger.getLogger(Crawler.class.getName()).log(Level.SEVERE, null, ex);
                } catch (FileNotFoundException ex) {
                    Logger.getLogger(Crawler.class.getName()).log(Level.SEVERE, null, ex);
                }
      System.out.println("Crawling Complete.");
      Crawler.f=1;
      FileOutputStream out = null;

      
        
                try {
                    out = new FileOutputStream("out.txt");
                     out.write(f);
                } catch (FileNotFoundException ex) {
                    Logger.getLogger(Crawler.class.getName()).log(Level.SEVERE, null, ex);
                } catch (IOException ex) {
                    Logger.getLogger(Crawler.class.getName()).log(Level.SEVERE, null, ex);
                }
         
       
        
           
              
   }
           
            
       }, 
        5 ,86400000
);
       
               
}
}