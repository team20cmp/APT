package crawler;
public class Steming_Part {
    
  /*  public static void main(String[] args) {
        Stemmer stem = new Stemmer();
        String words[]= new String [4];
        String stems_words[]= new String [4];
        words[0]="google";
        words[1]="fishes";
        words[2]="focus";
        words[3]="buses";
        stems_words =return_stem(words);
        for (int i=0;i<stems_words.length;i++)
            System.out.println(stems_words[i]);
           
    }*/
    //method to return the stem words in an array list
    public static String[] return_stem(String[] words){
        Stemmer stem = new Stemmer();
        //String arr_str[] = new String[words.length];
       for (int i=0;i<words.length;i++)
           if(words[i].length()!=0)
           words[i]=stem.Stemming(words[i]);
        return words;
    }
}

