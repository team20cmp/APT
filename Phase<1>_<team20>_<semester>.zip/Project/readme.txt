
to run the code 

1)run the crawler.java to download files in html folder 

2)after the crawler finished run main.java to index the doucemnts

3)you can check the data in the database


