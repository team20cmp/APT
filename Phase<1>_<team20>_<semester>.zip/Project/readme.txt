
to run the code 

1)run the crawler.java to download files in html folder 

2)after the crawler finished run main.java to index the doucemnts

3)you can check the data in the database

note:- put this JARs :
1- com.ibm.icu_3.4.4.1
2-commons-collections-3.0
3-icu4j-53.1
4-jrobotx-0.2
5-jrobotx-0.2-sources
6-jsoup-1.10.2
7-log4j-1.2.16
8-mysql-connector-java-5.1.41-bin
9-scala-library-2.11.7
10-scala-reflect-2.11.2
11-scalatest_2.11-2.2.3
12-scala-xml_2.11-1.0.2
13-url-normalization_2.10-0.3
14-util-core_2.11-0.1.15




https://github.com/team20cmp/APT
